package com.example.agecalculator

import android.icu.util.Calendar
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val etYear = findViewById<EditText>(R.id.etYear)
        val btnCalc = findViewById<Button>(R.id.btnCalc)
        val tvResult = findViewById<TextView>(R.id.tvResult)

        btnCalc.setOnClickListener {
            val yearText: String = etYear.text.toString()
            val birthYear: Int = yearText.toInt()
            val currentYear: Int = java.util.Calendar.getInstance().get(Calendar.YEAR)
            val age: Int = currentYear - birthYear

            val month: Int = age * 12
            val days: Int = age * 365
            val sleepYears: Double = age * 8 / 24.0

            val hour: Int = days * 24
            val minutes: Int = hour * 60
            val next_year: Int = age + 1

            tvResult.text = "Полных лет: $age\n" +
                    "Месяцев: $month\n" +
                    "Дней: примерно $days\n" +
                    "Часов: $hour\n" +
                    "Минут: $minutes\n" +
                    "В следующем году: $next_year\n" +
                    "Из них во сне, лет: " + "%.1f".format(sleepYears)



        }
    }
}