package com.example.grade

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val editText = findViewById<EditText>(R.id.etScore)
        val button = findViewById<Button>(R.id.btnCheck)
        val textView2 = findViewById<TextView>(R.id.tvGrade)
        val textView3 = findViewById<TextView>(R.id.tvComment)

        button.setOnClickListener {
            val text = editText.text.toString()
            if (text.isEmpty()) {
                textView2.text = "?"
                textView3.text = "Введите балы"

            } else {
                val score = text.toInt()

                if (score < 0 || score > 100) {
                    textView2.text = "?"
                    textView3.text = "Введите значение больше 0 и меньше 100"

                } else {
                    val grade = when (score) {
                        in 85..100 ->5
                        in 70..84 -> 4
                        in 50..69 -> 3
                        else -> 2
                    }
                    val comment = when (grade) {
                        5 -> "Отлично!"
                        4 -> "Хорошо!"
                        3 -> "Норм!"
                        else -> "Плохо"
                    }
                    val color = when(grade) {
                        5,4 -> R.color.grade_good
                        3 -> R.color.grade_normal
                        2 -> R.color.grade_bad
                        else -> R.color.question_sign
                    }
                    textView2.text = grade.toString()
                    textView3.text = comment
                    textView2.setTextColor(getColor(color))
                }

            }
        }
    }
}